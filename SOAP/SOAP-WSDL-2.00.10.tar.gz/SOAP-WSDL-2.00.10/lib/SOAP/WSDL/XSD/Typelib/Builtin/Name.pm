package SOAP::WSDL::XSD::Typelib::Builtin::Name;
use strict;
use warnings;
use Class::Std::Fast::Storable constructor => 'none', cache => 1;
use base qw(SOAP::WSDL::XSD::Typelib::Builtin::token);
Class::Std::initialize();
1;
