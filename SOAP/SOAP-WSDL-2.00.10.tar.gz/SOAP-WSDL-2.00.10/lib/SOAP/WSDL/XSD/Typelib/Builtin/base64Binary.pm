package SOAP::WSDL::XSD::Typelib::Builtin::base64Binary;
use strict;
use warnings;

use Class::Std::Fast::Storable constructor => 'none', cache => 1;
use base qw(SOAP::WSDL::XSD::Typelib::Builtin::anySimpleType);

1;

