package SOAP::WSDL::XSD::Typelib::Builtin::unsignedLong;
use strict;
use warnings;
use Class::Std::Fast::Storable constructor => 'none', cache => 1;
use base qw(SOAP::WSDL::XSD::Typelib::Builtin::nonNegativeInteger);

1;
