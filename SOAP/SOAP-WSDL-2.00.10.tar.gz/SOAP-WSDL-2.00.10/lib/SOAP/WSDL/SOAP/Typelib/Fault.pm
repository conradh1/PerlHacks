package SOAP::WSDL::SOAP::Typelib::Fault;
use strict;
use warnings;
use Class::Std::Fast::Storable constructor => 'none';

use version; our $VERSION = qv('2.00.10');

1;