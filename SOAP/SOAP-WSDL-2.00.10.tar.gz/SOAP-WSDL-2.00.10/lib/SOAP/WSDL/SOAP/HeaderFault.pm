package SOAP::WSDL::SOAP::HeaderFault;
use strict;
use warnings;
use base qw(SOAP::WSDL::Header);

use version; our $VERSION = qv('2.00.10');

1;